function addBranchUser() {
	$('#branchUserDialog').dialog("option", "title", 'Add Branch');
	$('#branchUserDialog').dialog('open');
}

function editBranchUser(lBid) {

	$.get("getBranchUser/" + lBid, function(result) {

		$("#branchUserDialog").html(result);

		$("#branchUserDialog").dialog("option", "title", 'Edit Branch');

		$("#branchUserDialog").dialog('open');

	
	});
}



function resetDialog(form) {

	form.find("input").val("");
}

$(document).ready(function() {

	$('#branchUserDialog').dialog({

		autoOpen : false,
		position : 'center',
		modal : true,
		resizable : false,
		width : 300,
		buttons : {
			"Save" : function() {
				$('#branchUserForm').submit();
			},
			"Cancel" : function() {
				$(this).dialog('close');
			}
		},
		close : function() {

			resetDialog($('#branchUserForm'));

			$(this).dialog('close');
		}
	});


});
