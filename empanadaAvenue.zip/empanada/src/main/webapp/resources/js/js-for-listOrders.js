

function showItems(lOrder_Number) {

	$.get("getItemsOrdered/" + lOrder_Number, function(result) {

		$("#itemsOrdered").html(result);

		

	
	});
}



