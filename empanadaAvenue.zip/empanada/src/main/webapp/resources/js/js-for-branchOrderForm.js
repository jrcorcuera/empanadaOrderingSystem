
//$( "#selectedItem" ).change(function() {
//	
//	var item = $('#selectedItem').find(":selected").val();
//	
//	var input = $("<c:out value='${itemList}' />");
//	alert(JSON.stringify(input));
//	$.each(input, function(i, obj){
//		
//		if(obj.lIid == item){
//			
//			alert("sdfsdfsdf");
//		}
//		else{alert("sdfsdfgdfgdgdfdfsdf");}
//	});
//  
//});

$(document).ready(function(){

		$("#add-item").click(addItem);
	
});


var count = 0;
function addItem(){
	count = count +1;
	var insert=
		
		
		'<div class="pure-control-group">' +
			'<label for="item">Item </label>' +
			'<select id="selectedItem'+ count+ '" name="item">' +
			
	        '</select>' +	
	        '<label for="quantity">Quantity</label>' +
	        '<input id="qty'+ count +'" type ="number" name="quantity" placeholder="quantity" onchange="totalPrice(this.id)" />' +
	        '<label>total</label>'+
          	'<input id="total'+ count +'" type ="text" placeholder="total"  readonly />'+
	    '</div>';
	
	$("#addHere").append(insert);
	
	 for(var i = 0; i < $('select#selectedItem0 option').length; i++){
		
		 $("#selectedItem" + count).append('<option value=' + $("#"+i+"").val()+' > '+  $("#"+i+"").text()  +'</option>'); 
	}
	 
	
}


//function addPrice(id){ 
//	var selected =$("#" + id).find('option:selected');
//	alert(selected.text());
//	
//}

function totalPrice(id){ 
	var selected =$("#selectedItem" + id.replace("qty", "")).find('option:selected');
	
	var txt= selected.text();
	var p = txt.split("P ");
	var total= parseInt(p[1]) * parseInt($("#" +id).val());
	$("#total"+id.replace("qty", "")).val(total);
	
	var grand = 0;
	for(var i=0; i<=count; i++){
		grand = grand  + parseInt($("#total" + i).val());
		
	}
	
	$("#grand").val(grand);
}	
	
//$(document).ready(function() {
//	
//	
//	$("#add-item").click(addItem);
//    
//    
//});
//
//
//function addItem(){
//	
////	var word = $("#words").val();
////	
////	var words = word.split(" ");
//	
//	//var allwords= {};
//	
//	//for( var i=0; i<words.length; i++){
//		
//	//	allwords["word"+i] = word[i];
//	//}
//	
//	
//	$.ajax({
//		   url: '/empanada/branch/xyz',
//		 //  data:{word0: words[0], word1: words[1], word2: words[2] },
//		     
//		 //  data:{words: words},
//		   error: function() {
//			   alert("error");
//		   },
//		   dataType: 'json',
//		   success: function(data) {
//			   
////			   $.each( data, function( i, obj ) {
////				   $("#container").append("<h1>"+obj.word+": "+obj.translation+"<h1>");
////				});
//			   
//			   alert(JSON.stringify(data));
//		   },
//		   type: 'POST'
//		});
//	
//	
//}	
//	