package com.empanada.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.empanada.model.AdminLogin;
import com.empanada.model.AdminUser;
import com.empanada.model.BranchUser;
import com.empanada.model.Item;
import com.empanada.model.UserLogin;
import com.empanada.service.MainService;

@Controller
@RequestMapping("/main")
public class MainController {

       @Autowired
       private MainService mainservice;
       
       
       @RequestMapping(value="/loginAdmin", method = RequestMethod.GET)
	   public ModelAndView login() {
	  			return new ModelAndView("/avenueMain/loginAdmin", "command", new AdminLogin());
	  			
	  }
       
       @RequestMapping(value="/processlogin", method = RequestMethod.POST)
	   public String processlogin(HttpSession session, ModelMap model, 
	  			@RequestParam(value="strUserName", defaultValue="") String name,
	  			@RequestParam(value="strPassword", defaultValue="") String password) {
	  		 
	  		 
	  		 	List<AdminUser> login = mainservice.checkAdminLogin(name, password);
	  		 	
	  		 
	  			
	  			if(!login.isEmpty()){
	  				AdminUser x = login.get(0);
	  				AdminLogin user = new AdminLogin(x.getlAid(), x.getStrUserName(), x.getStrFirstName(), x.getStrLastName());
	  			
	  				session.setAttribute("user", user);
	  				
	  				return "redirect:MainHome";
	  			}else{
	  				return "redirect:loginAdmin";
	  			}
	
	  	}
	  	 
       
       
       @RequestMapping(value = { "/", "/MainHome" })
       public String mainHome(HttpSession session) {
    	   if(session.getAttribute("user")==null){
				return "redirect:login";
		 }else
		 {
			 return "/avenueMain/MainHome";	
		 }

              
       }
       
       

       @RequestMapping(value = { "/", "/listItems" })
       public String listBooks(Map<String, Object> map, HttpSession session) {
    	   
    	 if(session.getAttribute("user")==null){
				return "redirect:loginAdmin";
	 	 }else
	 	 {
	          
	   	 	AdminLogin user = (AdminLogin) session.getAttribute("user");
   	 
	   	 	  map.put("user", user);

              map.put("item", new Item());

              map.put("itemList", mainservice.listItems());

              return "/avenueMain/listItems";
	 	 }    
       }
       
       
       @RequestMapping(value = { "/", "/listBranchUsers" })
       public String listBranchUsers(Map<String, Object> map, HttpSession session) {
    	   
    	  if(session.getAttribute("user")==null){
				return "redirect:loginAdmin";
	 	 }else
	 	 {
	          
	 		  AdminLogin user = (AdminLogin) session.getAttribute("user");
  	 
	   	 	  map.put("user", user);

              map.put("branchUser", new BranchUser());

              map.put("branchUserList", mainservice.listBranchUsers());

              return "/avenueMain/listBranchUsers";
	 	 }
       }
       
       @RequestMapping(value = { "/", "/listAdminUsers" })
       public String listAdminUsers(Map<String, Object> map, HttpSession session) {
    	   
    	   
    	 if(session.getAttribute("user")==null){
				return "redirect:loginAdmin";
	 	 }else
	 	 {
	          
	 		  AdminLogin user = (AdminLogin) session.getAttribute("user");
  	 
	   	 	  map.put("user", user);

              map.put("adminUser", new AdminUser());

              map.put("adminUserList", mainservice.listAdminUsers());

              return "/avenueMain/listAdminUsers";
	 	 }
       }

       @RequestMapping("/getItem/{lIid}")
       public String getBook(@PathVariable long lIid, Map<String, Object> map) {

              Item item = mainservice.getItem(lIid);

              map.put("item", item);

              return "/avenueMain/itemForm";
       }
       
       @RequestMapping("/getBranchUser/{lBid}")
       public String getBranchUser(@PathVariable long lBid, Map<String, Object> map) {

              BranchUser branchUser = mainservice.getBranchUser(lBid);

              map.put("branchUser", branchUser);

              return "/avenueMain/branchUserForm";
       }

       @RequestMapping("/getAdminUser/{lAid}")
       public String getAdminUser(@PathVariable long lAid, Map<String, Object> map) {

              AdminUser adminUser = mainservice.getAdminUser(lAid);

              map.put("adminUser", adminUser);

              return "/avenueMain/adminUserForm";
       }
       @RequestMapping(value = "/saveItem", method = RequestMethod.POST)
       public String saveBook(@ModelAttribute("item") Item item,
                     BindingResult result) {

              mainservice.saveItem(item);

              /*
               * Note that there is no slash "/" right after "redirect:"
               * So, it redirects to the path relative to the current path
               */
              return "redirect:listItems";
       }
       
       @RequestMapping(value = "/saveBranchUser", method = RequestMethod.POST)
       public String saveBranchUser(@ModelAttribute("branchuser") BranchUser branchuser,
                     BindingResult result) {

              mainservice.saveBranchUser(branchuser);

              /*
               * Note that there is no slash "/" right after "redirect:"
               * So, it redirects to the path relative to the current path
               */
              return "redirect:listBranchUsers";
       }
       
       @RequestMapping(value = "/saveAdminUser", method = RequestMethod.POST)
       public String saveAdminUser(@ModelAttribute("adminuser") AdminUser adminuser,
                     BindingResult result) {

              mainservice.saveAdminUser(adminuser);

              /*
               * Note that there is no slash "/" right after "redirect:"
               * So, it redirects to the path relative to the current path
               */
              return "redirect:listAdminUsers";
       }

       @RequestMapping("/deleteItem/{itemLIid}")
       public String deleteItem(@PathVariable("itemLIid")long itemLIid) {

              mainservice.deleteItem(itemLIid);

              return "redirect:/main/listItems";
       }
       
       
       @RequestMapping("/deleteBranchUser/{lBid}")
       public String deleteBranchUser(@PathVariable("lBid")long lBid) {

              mainservice.deleteBranchUser(lBid);

              return "redirect:/main/listBranchUsers";
       }
       
       @RequestMapping("/deleteAdminUser/{lAid}")
       public String deleteAdminUser(@PathVariable("lAid")long lAid) {

              mainservice.deleteAdminUser(lAid);

              return "redirect:/main/listAdminUsers";
       }
}