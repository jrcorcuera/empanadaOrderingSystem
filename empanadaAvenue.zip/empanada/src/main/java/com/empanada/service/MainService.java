package com.empanada.service;

import java.util.List;

import com.empanada.model.AdminUser;
import com.empanada.model.BranchUser;
import com.empanada.model.Item;
import com.empanada.model.OrderItem;
import com.empanada.model.OrderNumber;

public interface MainService {

       
       public void saveItem(Item item);
       public void saveBranchUser(BranchUser branchuser);
       public void saveAdminUser(AdminUser adminuser);	
       public void saveOrderItem(OrderItem orderItem);
       public void saveOrderNumber(OrderNumber num);
       
       
       public List<Item> listItems();
       public List<BranchUser> listBranchUsers();
       public List<AdminUser> listAdminUsers();
       public List<OrderNumber> lastRecord();
       public List<OrderNumber> listOrders(long lBid);
       
       public Item getItem(long lIid);
       public BranchUser getBranchUser(long lBid);
       public AdminUser getAdminUser(long lAid);
       
       public void deleteItem(long lIid);
       public void deleteBranchUser(long lBid);
       public void deleteAdminUser(long lAid);
       
       public List<BranchUser> checkLogin(long branchID, String name, String password);
       public List<AdminUser> checkAdminLogin(String name, String password);
       public List<OrderItem> getOrderedItems(long lOrder_Number);
       
       
      

}