package com.empanada.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "orderNumber")
public class OrderNumber {
	   private long lONid;
	   private long lOrder_Number;
	   private long lBid;
	   
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)   
	public long getlONid() {
		return lONid;
	}
	
	
	public void setlONid(long lONid) {
		this.lONid = lONid;
	}

	@Column(nullable = false)
	public long getlOrder_Number() {
		return lOrder_Number;
	}


	public void setlOrder_Number(long lOrder_Number) {
		this.lOrder_Number = lOrder_Number;
	}

	@Column(nullable = false)
	public long getlBid() {
		return lBid;
	}


	public void setlBid(long lBid) {
		this.lBid = lBid;
	}

   
}