package com.empanada.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "adminUser")
public class AdminUser {
	   private long lAid;
	   private String strUserName;
       private String strFirstName;
       private String strLastName;
       private String strPassword;
       
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)          
	public long getlAid() {
		return lAid;
	}
    
	public void setlAid(long lAid) {
		this.lAid = lAid;
	}
	
	@Column(nullable = false)
	public String getStrUserName() {
		return strUserName;
	}
	
	
	public void setStrUserName(String strUserName) {
		this.strUserName = strUserName;
	}
	
	@Column(nullable = false)
	public String getStrFirstName() {
		return strFirstName;
	}
	
	@Column(nullable = false)
	public void setStrFirstName(String strFirstName) {
		this.strFirstName = strFirstName;
	}
	
	@Column(nullable = false)
	public String getStrLastName() {
		return strLastName;
	}
	
	public void setStrLastName(String strLastName) {
		this.strLastName = strLastName;
	}
	
	@Column(nullable = false)
	public String getStrPassword() {
		return strPassword;
	}
	
	public void setStrPassword(String strPassword) {
		this.strPassword = strPassword;
	}
       
       
   
       
}