package com.empanada.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "item")
public class Item {
	   private long lIid;	
       private String strName;
       private String strType;
       private float fPrice;
     
       
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public long getlIid() {
		return lIid;
	}
  
   
	@Column(nullable = false)
	public String getStrName() {
		return strName;
	}
	
	

	@Column(length = 15, nullable = false)
	public String getStrType() {
		return strType;
	}
	
	
	
	@Column(nullable = false)
	public float getfPrice() {
		return fPrice;
	}


	


	public void setStrName(String strname) {
		this.strName = strname;
	}
	
	
	public void setStrType(String strtype) {
		this.strType = strtype;
	}
	
	public void setfPrice(float fPrice) {
		this.fPrice = fPrice;
	}
	
     
	public void setlIid(long lIid) {
		this.lIid = lIid;
	}
	

}