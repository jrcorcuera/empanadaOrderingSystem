package com.empanada.model;


import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "orderNumber")
public class OrderNumber {
	   private long lONid;
	   private long lOrder_Number;
	   private long lBid;
	   private Date dDateOrdered;
	   private String strStatus;
	   private String strRemarks;
	   public List<BranchUser> branchuser;
	   
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)   
	public long getlONid() {
		return lONid;
	}
	
	
	public void setlONid(long lONid) {
		this.lONid = lONid;
	}

	@Column(nullable = false)
	public long getlOrder_Number() {
		return lOrder_Number;
	}


	public void setlOrder_Number(long lOrder_Number) {
		this.lOrder_Number = lOrder_Number;
	}

	@Column(nullable = false)
	public long getlBid() {
		return lBid;
	}

	
	public void setlBid(long lBid) {
		this.lBid = lBid;
	}

	@Column(nullable = false)
	public Date getdDateOrdered() {
		return dDateOrdered;
	}


	public void setdDateOrdered(Date dDateOrdered) {
		this.dDateOrdered = dDateOrdered;
	}

	@Column(nullable = false)
	public String getStrStatus() {
		return strStatus;
	}


	public void setStrStatus(String strStatus) {
		this.strStatus = strStatus;
	}

	@Column(nullable = true)
	public String getStrRemarks() {
		return strRemarks;
	}


	public void setStrRemarks(String strRemarks) {
		this.strRemarks = strRemarks;
	}

   
}