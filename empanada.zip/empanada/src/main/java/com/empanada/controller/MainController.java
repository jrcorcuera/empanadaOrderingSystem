package com.empanada.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.empanada.model.AdminLogin;
import com.empanada.model.AdminUser;
import com.empanada.model.BranchUser;
import com.empanada.model.GetOrder;
import com.empanada.model.GetOrderNumberBranchInfo;
import com.empanada.model.Item;
import com.empanada.model.OrderItem;
import com.empanada.model.OrderNumber;
import com.empanada.model.UserLogin;
import com.empanada.service.MainService;

@Controller
@RequestMapping("/main")
public class MainController {

       @Autowired
       private MainService mainservice;
       
       
       @RequestMapping(value="/loginAdmin", method = RequestMethod.GET)
	   public ModelAndView login() {
	  			return new ModelAndView("/avenueMain/loginAdmin", "command", new AdminLogin());
	  			
	  }
       
      @RequestMapping(value="/logoutAdmin", method = RequestMethod.GET)
	  public String endsession(HttpSession session) {
				session.invalidate();
				
				return "redirect:loginAdmin"; 
				
	  }
       
       @RequestMapping(value="/processlogin", method = RequestMethod.POST)
	   public String processlogin(HttpSession session, ModelMap model, 
	  			@RequestParam(value="strUserName", defaultValue="") String name,
	  			@RequestParam(value="strPassword", defaultValue="") String password) {
	  		 
	  		 
	  		 	List<AdminUser> login = mainservice.checkAdminLogin(name, password);
	  		 	
	  		 
	  			
	  			if(!login.isEmpty()){
	  				AdminUser x = login.get(0);
	  				AdminLogin adminuser = new AdminLogin(x.getlAid(), x.getStrUserName(), x.getStrFirstName(), x.getStrLastName());
	  			
	  				session.setAttribute("adminuser", adminuser);
	  				
	  				return "redirect:MainHome";
	  			}else{
	  				return "redirect:loginAdmin";
	  			}
	
	  	}
	  	 
       
       
       @RequestMapping(value = { "/", "/MainHome" })
       public String mainHome(HttpSession session) {
    	   if(session.getAttribute("adminuser")==null){
				return "redirect:loginAdmin";
		 }else
		 {
			 return "/avenueMain/MainHome";	
		 }

              
       }
       
       

       @RequestMapping(value = { "/", "/listItems" })
       public String listBooks(Map<String, Object> map, HttpSession session) {
    	   
    	 if(session.getAttribute("adminuser")==null){
				return "redirect:loginAdmin";
	 	 }else
	 	 {
	          
	   	 	AdminLogin adminuser = (AdminLogin) session.getAttribute("adminuser");
   	 
	   	 	  map.put("adminuser", adminuser);

              map.put("item", new Item());

              map.put("itemList", mainservice.listItems());

              return "/avenueMain/listItems";
	 	 }    
       }
       
       
       @RequestMapping(value = { "/", "/listBranchUsers" })
       public String listBranchUsers(Map<String, Object> map, HttpSession session) {
    	   
    	  if(session.getAttribute("adminuser")==null){
				return "redirect:loginAdmin";
	 	 }else
	 	 {
	          
	 		  AdminLogin adminuser = (AdminLogin) session.getAttribute("adminuser");
  	 
	   	 	  map.put("adminuser", adminuser);

              map.put("branchUser", new BranchUser());

              map.put("branchUserList", mainservice.listBranchUsers());

              return "/avenueMain/listBranchUsers";
	 	 }
       }
       
       @RequestMapping(value = { "/", "/listAdminUsers" })
       public String listAdminUsers(Map<String, Object> map, HttpSession session) {
    	   
    	   
    	 if(session.getAttribute("adminuser")==null){
				return "redirect:loginAdmin";
	 	 }else
	 	 {
	          
	 		  AdminLogin adminuser = (AdminLogin) session.getAttribute("adminuser");
  	 
	   	 	  map.put("adminuser", adminuser);

              map.put("adminUser", new AdminUser());

              map.put("adminUserList", mainservice.listAdminUsers());

              return "/avenueMain/listAdminUsers";
	 	 }
       }
       
       @RequestMapping(value = { "/", "/listBranchOrders" })
       public String listOrderNumberBranchInfo(Map<String, Object> map, HttpSession session) {
      	 if(session.getAttribute("adminuser")==null){
  				return "redirect:loginAdmin";
  	 	 }else
  	 	 {
             // map.put("item", new Item());
  	 		 AdminLogin adminuser = (AdminLogin) session.getAttribute("adminuser");
  	 	  	 
	   	 	 map.put("adminuser", adminuser);
      	 	
	   	 	List<OrderNumber> orders = mainservice.getOrderNumberBranchInfo();
	    	List<GetOrderNumberBranchInfo> getorders = new ArrayList<GetOrderNumberBranchInfo>();
	        for (int i=0; i<orders.size(); i++){
	        	
	        	GetOrderNumberBranchInfo getordernumberbranchinfo =new GetOrderNumberBranchInfo(orders.get(i).getlONid(), orders.get(i).getlOrder_Number(),
	        			orders.get(i).getlBid(), orders.get(i).getdDateOrdered(), orders.get(i).getStrStatus(), orders.get(i).getStrRemarks(), orders.get(i).branchuser);
	        			
	    
	        	getorders.add(getordernumberbranchinfo);
	        
	        }
		    	
            map.put("ordersList", getorders);
            
            return "/avenueMain/listBranchOrders";
	 	 }
     }

       
       @RequestMapping(value = { "/", "/listDeliveredBranchOrders" })
       public String listOrderNumberBranchInfoDelivered(Map<String, Object> map, HttpSession session) {
      	 if(session.getAttribute("adminuser")==null){
  				return "redirect:loginAdmin";
  	 	 }else
  	 	 {
  	 		 AdminLogin adminuser = (AdminLogin) session.getAttribute("adminuser");
  	 	  	 
	   	 	 map.put("adminuser", adminuser);
      	 	
	   	 	List<OrderNumber> orders = mainservice.getOrderNumberBranchInfoDelivered();
	    	List<GetOrderNumberBranchInfo> getorders = new ArrayList<GetOrderNumberBranchInfo>();
	        for (int i=0; i<orders.size(); i++){
	        	
	        	GetOrderNumberBranchInfo getordernumberbranchinfo =new GetOrderNumberBranchInfo(orders.get(i).getlONid(), orders.get(i).getlOrder_Number(),
	        			orders.get(i).getlBid(), orders.get(i).getdDateOrdered(), orders.get(i).getStrStatus(), orders.get(i).getStrRemarks(), orders.get(i).branchuser);
	        			
	    
	        	getorders.add(getordernumberbranchinfo);
	        
	        }
		    	
            map.put("ordersList", getorders);
            
            return "/avenueMain/listDeliveredBranchOrders";
	 	 }
     }  
       @RequestMapping("/getItem/{lIid}")
       public String getBook(@PathVariable long lIid, Map<String, Object> map) {

              Item item = mainservice.getItem(lIid);

              map.put("item", item);

              return "/avenueMain/itemForm";
       }
       
       @RequestMapping("/getBranchUser/{lBid}")
       public String getBranchUser(@PathVariable long lBid, Map<String, Object> map) {

              BranchUser branchUser = mainservice.getBranchUser(lBid);

              map.put("branchUser", branchUser);

              return "/avenueMain/branchUserForm";
       }

       @RequestMapping("/getAdminUser/{lAid}")
       public String getAdminUser(@PathVariable long lAid, Map<String, Object> map) {

              AdminUser adminUser = mainservice.getAdminUser(lAid);

              map.put("adminUser", adminUser);

              return "/avenueMain/adminUserForm";
       }
       
       @RequestMapping(value = "/saveItem", method = RequestMethod.POST)
       public String saveBook(@ModelAttribute("item") Item item,
                     BindingResult result) {

              mainservice.saveItem(item);

              /*
               * Note that there is no slash "/" right after "redirect:"
               * So, it redirects to the path relative to the current path
               */
              return "redirect:listItems";
       }
       
       @RequestMapping(value = "/saveBranchUser", method = RequestMethod.POST)
       public String saveBranchUser(@ModelAttribute("branchuser") BranchUser branchuser,
                     BindingResult result) {

              mainservice.saveBranchUser(branchuser);

              /*
               * Note that there is no slash "/" right after "redirect:"
               * So, it redirects to the path relative to the current path
               */
              return "redirect:listBranchUsers";
       }
       
       @RequestMapping(value = "/saveAdminUser", method = RequestMethod.POST)
       public String saveAdminUser(@ModelAttribute("adminuser") AdminUser adminuser,
                     BindingResult result) {

              mainservice.saveAdminUser(adminuser);

              /*
               * Note that there is no slash "/" right after "redirect:"
               * So, it redirects to the path relative to the current path
               */
              return "redirect:listAdminUsers";
       }

       @RequestMapping("/deleteItem/{itemLIid}")
       public String deleteItem(@PathVariable("itemLIid")long itemLIid) {

              mainservice.deleteItem(itemLIid);

              return "redirect:/main/listItems";
       }
       
       
       @RequestMapping("/deleteBranchUser/{lBid}")
       public String deleteBranchUser(@PathVariable("lBid")long lBid) {

              mainservice.deleteBranchUser(lBid);

              return "redirect:/main/listBranchUsers";
       }
       
       @RequestMapping("/deleteAdminUser/{lAid}")
       public String deleteAdminUser(@PathVariable("lAid")long lAid) {

              mainservice.deleteAdminUser(lAid);

              return "redirect:/main/listAdminUsers";
       }
       
       @RequestMapping("/getItemsOrderedMain/{lOrder_Number}")
       public String getBook(@PathVariable String lOrder_Number, Map<String, Object> map,HttpSession session) {
      	 if(session.getAttribute("adminuser")==null){
  				return "redirect:loginAdmin";
  	 	 }else
  	 	 {
  	 		AdminLogin adminuser = (AdminLogin) session.getAttribute("adminuser");
  	   	 
	   	 	map.put("adminuser", adminuser);
  	    	
	   	 	String [] info = lOrder_Number.split("=");
      	 	
  	    	List<OrderItem> orders = mainservice.getOrderedItems(Long.parseLong(info[0]));
  	    	List<GetOrder> getorders = new ArrayList<GetOrder>();

  	    	for (int i=0; i<orders.size(); i++){
  	        	
  	        	GetOrder getorder =new GetOrder(orders.get(i).getlOrder_Number(),orders.get(i).getlIid(), orders.get(i).getQuantity(),orders.get(i).Items );
  	        	getorders.add(getorder);
  	        
  	        }
  		    	
              map.put("branchid", info[1]);
              map.put("branchname", info[2]);
              map.put("address",info[3]);
              map.put("orderedItemsList", getorders);
              
              return "/avenueMain/displaybranchOrderMain";
  	 	 }
       }
       @RequestMapping(value="/approveOrder", method = RequestMethod.POST)
	   public String approveOrder( 
	  			@RequestParam(value="remark", defaultValue="") String remark,
	  			@RequestParam(value="lOrder_Number", defaultValue="") long lOrder_Number) {

              mainservice.approveOrder(remark, lOrder_Number);

              return "redirect: listBranchOrders";
       }
       
       @RequestMapping(value="/disapproveOrder", method = RequestMethod.POST)
	   public String disapproveOrder( 
	  			@RequestParam(value="remark", defaultValue="") String remark,
	  			@RequestParam(value="lOrder_Number", defaultValue="") long lOrder_Number) {

              mainservice.disapproveOrder(remark, lOrder_Number);

              return "redirect: listBranchOrders";
       }
       
       
}