

function showItems(lOrder_Number) {

	$.get("getItemsOrdered/" + lOrder_Number, function(result) {

	
		$("#itemDialog").html(result);

		$("#itemDialog").dialog("option", "title", 'View Items Ordered');

		$("#itemDialog").dialog('open');
		

	
	});
}


function resetDialog(form) {

	form.find("input").val("");
}


$(document).ready(function() {

	$('#itemDialog').dialog({

		autoOpen : false,
		position : 'center',
		modal : true,
		resizable : false,
		width : 780,
		buttons : {
			
			"Back" : function() {
				$(this).dialog('close');
			}
		},
		close : function() {

			resetDialog($('#displaybranchOrder'));

			$(this).dialog('close');
		}
	});


});
