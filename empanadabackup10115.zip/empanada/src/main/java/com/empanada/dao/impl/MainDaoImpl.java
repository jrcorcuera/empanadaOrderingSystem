package com.empanada.dao.impl;

import java.util.ArrayList;
import java.util.List;












import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.empanada.dao.MainDao;
import com.empanada.model.AdminUser;
import com.empanada.model.BranchUser;
import com.empanada.model.Item;
import com.empanada.model.OrderItem;
import com.empanada.model.OrderNumber;

@Repository
public class MainDaoImpl implements MainDao {

       @Autowired
       private SessionFactory sessionFactory;

       public void saveItem(Item item) {
              
              getSession().merge(item);
       }
       
       public void saveBranchUser(BranchUser branchuser){
           
    	   	  getSession().merge(branchuser);
       }
       
       public void saveAdminUser(AdminUser adminuser){
           
	 	   	  getSession().merge(adminuser);
	   }
       
       
       public void saveOrderItem(OrderItem orderItem){
           
	 	   	  getSession().merge(orderItem);
	   }
       
       public void saveOrderNumber(OrderNumber num){
           
	 	   	  getSession().merge(num);
	   }
       
       @SuppressWarnings("unchecked")
       public List<Item> listItems() {

            return getSession().createCriteria(Item.class).list();
       }
       
       @SuppressWarnings("unchecked")
       public List<BranchUser> listBranchUsers(){
	    	   
	    	return getSession().createCriteria(BranchUser.class).list();
    	   
       }
       
       @SuppressWarnings("unchecked")
       public List<AdminUser> listAdminUsers(){
    	   
    	    return getSession().createCriteria(AdminUser.class).list();
       }
       
     
       public Item getItem(long lIid) {
           return (Item) getSession().get(Item.class, lIid);
       }

       public BranchUser getBranchUser(long lBid){
           return (BranchUser) getSession().get(BranchUser.class, lBid);
       }
       
       public AdminUser getAdminUser(long lAid){
    	   
    	   return (AdminUser) getSession().get(AdminUser.class, lAid);
       }
       
       public OrderNumber getOrderNumber(long lONid){
    	   
    	   return (OrderNumber) getSession().get(OrderNumber.class, lONid);
       }
       
       public OrderItem getOrderItem(long lOid){
    	   
    	   return (OrderItem) getSession().get(OrderItem.class, lOid);
       }
       
       public void deleteItem (long lIid) {

              Item item = getItem(lIid);

              if (null != item) {
                     getSession().delete(item);
              }
       }
       
       
       public void deleteBranchUser(long lBid){

	         BranchUser branchuser = getBranchUser(lBid);
	
	         if (null != branchuser) {
	             getSession().delete(branchuser);
	         }
	    }
       
       
       
       public void deleteAdminUser(long lAid){
    	   
    	   	AdminUser adminuser = getAdminUser(lAid);
    	   	
    	   	if(null != adminuser){
    	   		getSession().delete(adminuser);
    	   	}
       }

       
       @SuppressWarnings("unchecked")
       public void deleteOrderAndItem(long lOrder_Number){
    	   Criteria cr = getSession().createCriteria(OrderNumber.class);
    	   cr.add(Restrictions.eq("lOrder_Number",lOrder_Number));
    	   
    	   List<OrderNumber> ordernumber = cr.list();
    	   
    	   for(int i=0; i<ordernumber.size(); i++){
    		   
    		  if( ordernumber.get(i).getlOrder_Number() == lOrder_Number){}
    		   OrderNumber ordnum = getOrderNumber(ordernumber.get(i).getlONid());
    		   
    		   if(null != ordnum){
   	   	   		getSession().delete(ordnum);
    		   }
    	   }
    	   
    	   Criteria cr2 = getSession().createCriteria(OrderItem.class);
    	   cr.add(Restrictions.eq("lOrder_Number",lOrder_Number));
    	   
    	   List<OrderItem> orderitem = cr2.list();
    	   
    	   for(int i=0; i<orderitem.size(); i++){
    		   
    		  if( orderitem.get(i).getlOrder_Number() == lOrder_Number){
    		   OrderItem orditm = getOrderItem(orderitem.get(i).getlOid());
    		   
	    		   if(null != orditm){
	   	   	   		getSession().delete(orditm);
	    		   }
    		  }
	   	 
    	   }
	   	   	
       }
       
       
       private Session getSession() {
              Session sess = getSessionFactory().getCurrentSession();
              if (sess == null) {
                     sess = getSessionFactory().openSession();
              }
              return sess;
       }

       private SessionFactory getSessionFactory() {
              return sessionFactory;
       }
       
       @SuppressWarnings("unchecked")
       public List<OrderNumber> lastRecord(){
    	   
    	   DetachedCriteria maxId = DetachedCriteria.forClass(OrderNumber.class)
    			    .setProjection( Projections.max("lONid") );
    	   Criteria cr =  getSession().createCriteria(OrderNumber.class);
    	   return cr.add( Property.forName("lONid").eq(maxId) )
    			    .list();
          // return getSession().createCriteria(Item.class).list();
      }

       @SuppressWarnings("unchecked")
       public List<BranchUser> checkLogin(long branchID, String name, String password){
    	   
    	   Criteria cr = getSession().createCriteria(BranchUser.class);
    	   cr.add(Restrictions.eq("lBid", branchID));
    	   cr.add(Restrictions.eq("strBranchName", name));
    	   cr.add(Restrictions.eq("strPassword", password));
    	   
    	   return  cr.list();
    	   
          // return (Item) getSession().get(Item.class, lIid);
       }
       
       @SuppressWarnings("unchecked")
       public List<AdminUser> checkAdminLogin(String name, String password){
    	   
    	   Criteria cr = getSession().createCriteria(AdminUser.class);
    	   cr.add(Restrictions.eq("strUserName", name));
    	   cr.add(Restrictions.eq("strPassword", password));
    	   
    	   return  cr.list();
    	   
          // return (Item) getSession().get(Item.class, lIid);
       }
       
       @SuppressWarnings("unchecked")
       public List<OrderNumber> listOrders(long lBid){
    	   
    	   Criteria cr = getSession().createCriteria(OrderNumber.class);
    	   cr.add(Restrictions.eq("lBid", lBid));
    	   cr.add(Restrictions.ne("strStatus", "Delivered"));
    	   return  cr.list();
    	   
      
       }
       
       @SuppressWarnings("unchecked")
       public List<OrderNumber> listDeliveredOrders(long lBid){
    	   
    	   Criteria cr = getSession().createCriteria(OrderNumber.class);
    	   cr.add(Restrictions.eq("strStatus", "Delivered"));
    	   return  cr.list();
    	   
      
       }
       
       @SuppressWarnings("unchecked")
       public List<OrderItem> getOrderedItems(long lOrder_Number){
    	   
    	   List<OrderItem> mainOrder = new ArrayList<OrderItem>(); 
    	   Criteria cr = getSession().createCriteria(OrderItem.class);
    	   cr.add(Restrictions.eq("lOrder_Number", lOrder_Number));
    	   
    	   mainOrder = cr.list();
    	   for(int i = 0; i < mainOrder.size(); i++)
    	   {
    		   
    		   Criteria cr2 = getSession().createCriteria(Item.class);
    		   cr2.add(Restrictions.eq("lIid", mainOrder.get(i).getlIid()));
    		   
    		   mainOrder.get(i).Items = cr2.list();
    	   }
    	   
    	   return  mainOrder;
       }

       
    @SuppressWarnings("unchecked")
	public List<OrderNumber> getOrderNumberBranchInfo(){
    	   
    	   List<OrderNumber> mainOrder = new ArrayList<OrderNumber>(); 
    	   Criteria cr = getSession().createCriteria(OrderNumber.class);
    	   cr.add(Restrictions.ne("strStatus","Delivered"));
    	   
    	   mainOrder = cr.list();
    	   for(int i = 0; i < mainOrder.size(); i++)
    	   {
    		   
    		   Criteria cr2 = getSession().createCriteria(BranchUser.class);
    		   cr2.add(Restrictions.eq("lBid", mainOrder.get(i).getlBid()));
    		   
    		   mainOrder.get(i).branchuser = cr2.list();
    	   }
    	   
    	   return  mainOrder;
       }
       
    @SuppressWarnings("unchecked")
	public List<OrderNumber> getOrderNumberBranchInfoDelivered(){
    	   
    	   List<OrderNumber> mainOrder = new ArrayList<OrderNumber>(); 
    	   Criteria cr = getSession().createCriteria(OrderNumber.class);
    	   cr.add(Restrictions.eq("strStatus","Delivered"));
    	  
    	   mainOrder = cr.list();
    	   for(int i = 0; i < mainOrder.size(); i++)
    	   {
    		   
    		   Criteria cr2 = getSession().createCriteria(BranchUser.class);
    		   cr2.add(Restrictions.eq("lBid", mainOrder.get(i).getlBid()));
    		   
    		   mainOrder.get(i).branchuser = cr2.list();
    	   }
    	   
    	   return  mainOrder;
       }
       
    
    @SuppressWarnings("unchecked")
	public void approveOrder(String remark, long lOrder_Number){
    	
           Criteria cr = getSession().createCriteria(OrderNumber.class);
	 	   cr.add(Restrictions.eq("lOrder_Number",lOrder_Number));
	 	   
	 	   List<OrderNumber> ordernumber = cr.list();
	 	   
	 	   for(int i=0; i<ordernumber.size(); i++){
	 		   
	 		  if( ordernumber.get(i).getlOrder_Number() == lOrder_Number){}
	 		   OrderNumber order = getOrderNumber(ordernumber.get(i).getlONid());
	 		   
	 		   if(null != order){
	 			   
	 			  order.setStrStatus("Approved For Delivery");
	 			  order.setStrRemarks(remark);
		   	   	  getSession().update(order);
	 		   }
	 	   }
    	
    	
    } 
    
    
    
    @SuppressWarnings("unchecked")
	public void disapproveOrder(String remark, long lOrder_Number){
    	
           Criteria cr = getSession().createCriteria(OrderNumber.class);
	 	   cr.add(Restrictions.eq("lOrder_Number",lOrder_Number));
	 	   
	 	   List<OrderNumber> ordernumber = cr.list();
	 	   
	 	   for(int i=0; i<ordernumber.size(); i++){
	 		   
	 		  if( ordernumber.get(i).getlOrder_Number() == lOrder_Number){}
	 		   OrderNumber order = getOrderNumber(ordernumber.get(i).getlONid());
	 		   
	 		   if(null != order){
	 			   
	 			  order.setStrStatus("Disapproved");
	 			  order.setStrRemarks(remark);
		   	   	  getSession().update(order);
	 		   }
	 	   }
    	
    	
    } 
       
    @SuppressWarnings("unchecked")
	public void reportDelivery(long lOrder_Number){
    	
        Criteria cr = getSession().createCriteria(OrderNumber.class);
	 	   cr.add(Restrictions.eq("lOrder_Number",lOrder_Number));
	 	   
	 	   List<OrderNumber> ordernumber = cr.list();
	 	   
	 	   for(int i=0; i<ordernumber.size(); i++){
	 		   
	 		  if( ordernumber.get(i).getlOrder_Number() == lOrder_Number){}
	 		   OrderNumber order = getOrderNumber(ordernumber.get(i).getlONid());
	 		   
	 		   if(null != order){
	 			   
	 			  order.setStrStatus("Delivered");
	 			  order.setStrRemarks("");
		   	   	  getSession().update(order);
	 		   }
	 	   }
 	
 	
 } 
    
    
    
    
    
}