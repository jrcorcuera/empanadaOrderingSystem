package com.empanada.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "branchuser")
public class BranchUser {
	   private long lBid;	
       private String strBranchName;
       private String strPassword;
       private String strOwner;
       private String strAddress;
       
       
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)   
	public long getlBid() {
		return lBid;
	}
    
	public void setlBid(long lBid) {
		this.lBid = lBid;
	}
	
	@Column(nullable = false)
	public String getStrBranchName() {
		return strBranchName;
	}
	
	public void setStrBranchName(String strBranchName) {
		this.strBranchName = strBranchName;
	}
	
	@Column(nullable = false)
	public String getStrPassword() {
		return strPassword;
	}
	
	public void setStrPassword(String strPassword) {
		this.strPassword = strPassword;
	}
	
	@Column(nullable = false)
	public String getStrOwner() {
		return strOwner;
	}
	
	public void setStrOwner(String strOwner) {
		this.strOwner = strOwner;
	}
	
	@Column(nullable = false)
	public String getStrAddress() {
		return strAddress;
	}
	
	public void setStrAddress(String strAddress) {
		this.strAddress = strAddress;
	}
     
      
     
       
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    public long getlBid() {
//              return lBid;
//    }     
//  
//   
//	@Column(nullable = false)
//	public String getName() {
//		return name;
//	}
//	
//	 @Column(length = 15, nullable = false)
//	public String getType() {
//		return type;
//	}
//	
//	 @Column(nullable = false)
//	public float getPrice() {
//		return price;
//	}
//	
//	
//	
//	public void setName(String name) {
//		this.name = name;
//	}
//	
//	
//	public void setType(String type) {
//		this.type = type;
//	}
//	
//	
//	public void setPrice(float price) {
//		this.price = price;
//	}
//     
//
//	public void setId(long id) {
//		this.id = id;
//	}
       
       
       
}