


$(document).ready(function(){

		$("#add-item").click(addItem);
		$("#delete-item").click(deleteItem);
	
});


var count = 0;
function addItem(){
	
	$("#save").prop("disabled", true);
	
	var head =
		'<th width="auto"></th>'+
	    '<th width="auto">Item</th>'+
	    '<th width="auto">Qty.</th>'+
	    '<th width="auto">Total Price</th>';
	
	var totalRow = 
		'<td></td>'+
	    '<td></td>'+
	    '<td>Total Price</td>'+
	    '<td><input  id="grand" type ="text"   readonly /></td>';
	
	var body=
		'<tr id = "div'+count+'"class="pure-control-group">' +
			'<td><input type="checkbox" value="div'+count+'"></td>' +
			'<td><select id="selectedItem'+ count+ '" name="item" onchange="totalPrice('+ count+ '); inputCheck()"></select></td>' +
	        '<td><input id="qty'+ count +'" type ="number" name="quantity" value="0" placeholder="quantity" onchange="totalPrice('+ count +'); inputCheck()" /></td>' +
          	'<td><input class="total" id= "total'+count+'" type ="text" value="0"  readonly /></td>'+
	    '</tr>';
	$("#head").html(head);
	$("#addHere").append(body);
	$("#totalRow").html(totalRow);
	
	 for(var i = 0; i < $('select#selectedItem option').length; i++){
		
		 $("#selectedItem" + count).append('<option value=' + $("#"+i).val()+' > '+  $("#"+i).text()  +'</option>'); 
	}
	 
	 count = count +1;
}

function deleteItem(){
	
//	if (count != 0){
//		$( "#div"+count ).remove();
//		count = count -1;
	
	$("input[type=checkbox]:checked").each(function() {
         $("#"+ $(this).val()).remove();
    });
		getGrandTotal();
		inputCheck();
//	}
}


function totalPrice(id){ 
	var selected =$("#selectedItem" + id).find('option:selected');
	
	var txt= selected.text();
	var p = txt.split("P ");
	var total= parseInt(p[1]) * parseInt($("#qty" +id).val());
	$("#total"+id).val(total);
	
//  var grand = 0;
//	for(var i=0; i<=count; i++){
//		grand = grand  + parseInt($("#total" + i).val());
//		
//	}
//	
	getGrandTotal();
	
}	


function inputCheck(){ 
	$("#save").prop("disabled", true);
	for(var i = 0; i<=count; i++) {
		if($("#qty"+ i).val() <= "0" ){
			break;
		}
		if(i == count){
			$("#save").prop("disabled", false);
		}

	}
}


function getGrandTotal(){ 
	var grand = 0;
	//for(var i=0; i<=count; i++){
	//	grand = grand  + parseInt($("#total" + i).val());
	//	
	//}
	//
	$(".total").each(function() {
	    grand = grand + parseInt($(this).val());
	});
	
	$("#grand").val(grand);
	
}